const show=()=>{
    const shows=document.querySelector("#signup")
    shows.classList.toggle("show")
}

const hide=()=>{
    const hides=document.querySelector("#signup")
    hides.classList.remove("show")
}
$(document).ready(function(){
    if($('#mail').val()!=""){

    }else  if($('#pass').val()!=""){

    }else
    {
        $('error').text('Email or password can not be empty');
        $('error').fadein("slow");
    }

});